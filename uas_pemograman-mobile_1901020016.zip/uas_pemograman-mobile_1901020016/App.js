import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Note_app from './Note_app';

const App = () => {
  return (
    <View style = {{flex: 1}}>
      <Note_app />
    </View>
  )
};
export default App;
