import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import axios from 'axios';

const NoteApp = () => {
  const [notes, setNotes] = useState([]);
  const [judul, setJudul] = useState('');
  const [konten, setKonten] = useState('');

  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    try {
      const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
      setNotes(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  const tambahNote = async () => {
    try {
      const response = await axios.post('https://jsonplaceholder.typicode.com/posts', {
        judul: judul,
        konten: konten,
      });
      setNotes([...notes, response.data]);
      setJudul('');
      setKonten('');
    } catch (error) {
      console.log(error);
    }
  };

  const hapusNote = async (id) => {
    try {
      await axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`);
      const updatedNotes = notes.filter((note) => note.id !== id);
      setNotes(updatedNotes);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <View>
      <Text>Note / Catatan Saya</Text>
      <TextInput
        placeholder="judul"
        value={judul}
        onChangeText={(text) => setJudul(text)}
      />

      <TextInput
        placeholder="Isi Konten"
        value={konten}
        onChangeText={(text) => setKonten(text)}
      />

      <Button title="Tambah Note" onPress={tambahNote} />

      {notes.map((note) => (
        <View key={note.id}>
          <Text>{note.judul}</Text>
          <Text>{note.konten}</Text>
          <Button title="Hapus Note" onPress={() => hapusNote(note.id)} />
        </View>
      ))}
    </View>
  );
};

export default NoteApp;
